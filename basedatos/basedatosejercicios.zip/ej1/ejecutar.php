<?php
drop database empleadosnn;

?>
